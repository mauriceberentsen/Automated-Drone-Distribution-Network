/**
 * @file RosDroneEngineConnector.hpp
 * @author M.W.J. Berentsen (mauriceberentsen@live.nl)
 * @brief header file for RosDroneEngineConnector
 * @version 1.0
 * @date 2019-04-24
 *
 * @copyright Copyright (c) 2019
 *
 */
#ifndef ROSDRONEENGINECONNECTOR
#define ROSDRONEENGINECONNECTOR
// ros libary
#include "ros/ros.h"
#include "drone_meshnetwork_simulation/Location.h"
// local header
#include "../Drone/IDroneEngine.hpp"

namespace ros
{
namespace Drone
{
 class RosDroneEngineConnector : public ::Drone::IDroneEngine
 {
 public:
  explicit RosDroneEngineConnector( uint16_t droneID );
  ~RosDroneEngineConnector( );
  /**
   * @brief Uses Ros transport to send a goal to the virtual engine
   *
   * @param latitude
   * @param longitude
   * @param height
   */
  void setGoal( const float latitude, const float longitude,
                const float height );
  /**
   * @brief Get the Location of the drone
   *
   * @return const Vector3< float > Current location of the
   * drone
   */
  const Vector3< float > getLocation( );

  void turnOn( );
  /**
   * @brief Turns the engine off
   *
   */
  void turnOff( );

 private:
  /// \brief the ID of the connected engine
  uint16_t ID;
  /// \brief Publisher towards the DroneEngine
  ros::Publisher droneEngine;
  /// \brief Service for requesting the current location
  ros::ServiceClient GPSLink;
  /// \brief Pointer to the Ros Node of this class
  std::shared_ptr< ros::NodeHandle > rosNode;
 };
}  // namespace Drone
}  // namespace ros
#endif  // RosDroneEngineConnector